package distinctcount;

import java.util.function.Predicate;

              public class Filter {
	                public static Predicate<String> nameStartingWithPrefix(String pred){
	                                     return ch->ch.startsWith(pred);
		        }
}




